#include<iostream>
int main()
{
  int id,t;
  std::cin>>id>>t;
  std::cout<<"Id : "<<id<<"\nTotalmarks : "<<t;
}
