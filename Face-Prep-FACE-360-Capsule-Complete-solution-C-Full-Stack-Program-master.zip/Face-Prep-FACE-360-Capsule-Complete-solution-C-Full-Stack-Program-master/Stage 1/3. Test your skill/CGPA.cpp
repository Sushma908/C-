#include<iostream>
int main()
{
  float marks;
  std::cin>>marks;
  std::cout<<marks;
}
