#include<iostream>

int main()
{
	char str[100];
  	std::cin>>str;
  	std::cout<<str;
}
  
