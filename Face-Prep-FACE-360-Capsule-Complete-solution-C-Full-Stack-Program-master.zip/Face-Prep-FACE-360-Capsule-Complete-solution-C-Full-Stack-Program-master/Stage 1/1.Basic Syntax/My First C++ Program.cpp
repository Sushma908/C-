#include<iostream>
int main()
{
  std::cout<<"My First C++ Program";
}
