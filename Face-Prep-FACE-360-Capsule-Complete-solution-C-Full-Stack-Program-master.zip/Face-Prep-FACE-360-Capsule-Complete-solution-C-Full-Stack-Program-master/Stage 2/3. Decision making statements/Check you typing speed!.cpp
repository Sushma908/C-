#include<iostream>
int main()
{
  int id,n;
  std::cin>>id>>n;
  (n>0)?std::cout<<id<<" is eligible for reward.":std::cout<<"";
}
