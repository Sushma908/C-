#include<iostream>
int main()
{
  int a;
  std::cin>>a;
  if(a>=0)
    std::cout<<a<<" is a positive number.";
  else
    std::cout<<a<<" is a negative number.";
}
