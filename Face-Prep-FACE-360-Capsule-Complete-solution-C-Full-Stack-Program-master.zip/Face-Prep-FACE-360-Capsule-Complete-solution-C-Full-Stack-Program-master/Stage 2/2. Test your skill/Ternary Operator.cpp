#include<iostream>
using namespace std;
int main()
{
  int n;
  std::cin>>n;
  (n%2==0)?std::cout<<"Even":std::cout<<"Odd";
}
