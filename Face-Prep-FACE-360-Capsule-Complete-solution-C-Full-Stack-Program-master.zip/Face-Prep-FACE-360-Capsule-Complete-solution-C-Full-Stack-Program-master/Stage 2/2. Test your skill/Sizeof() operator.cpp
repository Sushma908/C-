#include<iostream>
using namespace std;
int main()
{
  //char a;
   //int b;
  //float c;
  //double d;
  std::cout<<sizeof(char)<<"\n";
   std::cout<<sizeof(int)<<"\n";
   std::cout<<sizeof(float)<<"\n";
   std::cout<<sizeof(double)<<"\n";
  
}
