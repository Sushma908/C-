#include<iostream>
int main()
{
  int n;
  std::cin>>n;
  (n%2==0)?std::cout<<"Possible":std::cout<<"Not possible";
}
