#include<iostream>
using namespace std;
int main()
{
  int n,z=11,i;
  cin>>n;
  for(i=0;i<n;i++)
  {
    cout<<z*z<<" ";
    z+=4;
  }
      
}
