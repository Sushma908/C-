#include<iostream>
#include<cstring>
using namespace std;
int main()
{
  char str[50];
  cin.getline(str,50);
    cout<<"The number of letters in the name is "<<strlen(str);
}
